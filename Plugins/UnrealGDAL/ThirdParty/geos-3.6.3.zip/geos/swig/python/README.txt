Since version 3.0, the Python bindings are unsupported. Recommended options:

 1. Become or recruit a new maintainer.
 2. Use Shapely (http://pypi.python.org/pypi/Shapely) with Python versions 2.4 or greater.
 3. Simply call functions from libgeos_c via Python ctypes. Examples abound in the GeoDjango or Shapely code.
 
See also http://trac.osgeo.org/geos/ticket/228